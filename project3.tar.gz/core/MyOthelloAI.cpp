#include <ics46/factory/DynamicFactory.hpp>
#include "MyOthelloAI.hpp"

//circinus-46.ics.uci.edu
//4603

ICS46_DYNAMIC_FACTORY_REGISTER(OthelloAI, johnc16::MyOthelloAI, "Bot Jonas (REQUIRED)");


int johnc16::MyOthelloAI::eval(const OthelloGameState& state,OthelloCell& x)
{
    if(ai == true)
    {
        result = state.blackScore() - state.whiteScore();
        if(x == OthelloCell::black)
        {
            if(state.board().cellAt(1,1) == OthelloCell::white)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
            if(state.board().cellAt(state.board().height()-2,1) == OthelloCell::white)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
            if(state.board().cellAt(1,state.board().width()-2) == OthelloCell::white)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
            if(state.board().cellAt(state.board().height()-2,state.board().width()-2) == OthelloCell::white)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
        }

    }
    else
    {
        result = state.whiteScore() - state.blackScore();
        if(x == OthelloCell::white)
        {
            if(state.board().cellAt(1,1) == OthelloCell::black)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
            if(state.board().cellAt(state.board().height()-2,1) == OthelloCell::black)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
            if(state.board().cellAt(1,state.board().width()-2) == OthelloCell::black)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
            if(state.board().cellAt(state.board().height()-2,state.board().width()-2) == OthelloCell::black)
            {
                result = result+100;
            }
            else
            {
                result = result-100;
            }
        }
    }
    return result;
}

int johnc16::MyOthelloAI::search(const OthelloGameState& state, int depth)
{
    OthelloCell color;
    if(state.isBlackTurn())
    {
        color = OthelloCell::black;
    }
    if(state.isWhiteTurn())
    {
        color = OthelloCell::white;
    }
    if(depth == 0)
    {
        return eval(state,color);
    }
    else if(ai == true)
    {
        if(color == OthelloCell::black)
        {
            int a = -999;
            std::unique_ptr<OthelloGameState> s = state.clone();
            for(unsigned int i = 0;i<=s->board().width()-1;i++)
            {
                for(unsigned int j =0;j<=s->board().height()-1;j++)
                {
                    if(s->isValidMove(i,j))
                    {
                        s->makeMove(i,j);
                        int b = search(*s,depth-1);
                        if(b > a)
                        {
                            a = b;
                        }
                    }
                }
            }
            return a;
        }
        else
        {
            int a = 999;
            std::unique_ptr<OthelloGameState> s = state.clone();
            for(unsigned int i = 0;i<=s->board().width()-1;i++)
            {
                for(unsigned int j =0;j<=s->board().height()-1;j++)
                {
                    if(s->isValidMove(i,j))
                    {
                        s->makeMove(i,j);
                        int b = search(*s,depth-1);
                        if(b < a)
                        {
                            a = b;
                        }
                    }
                }
            }
            return a;
        }
        
    }
    else
    {
        if(color == OthelloCell::white)
        {
            int a = -999;
            std::unique_ptr<OthelloGameState> s = state.clone();
            for(unsigned int i = 0;i<=s->board().width()-1;i++)
            {
                for(unsigned int j =0;j<=s->board().height()-1;j++)
                {
                    if(s->isValidMove(i,j))
                    {
                        s->makeMove(i,j);
                        int b = search(*s,depth-1);
                        if(b < a)
                        {
                            a = b;
                        }
                    }
                }
            }
            return a;
        }
        else
        {
            int a = 999;
            std::unique_ptr<OthelloGameState> s = state.clone();
            for(unsigned int i = 0;i<=s->board().width()-1;i++)
            {
                for(unsigned int j =0;j<=s->board().height()-1;j++)
                {
                    if(s->isValidMove(i,j))
                    {
                        s->makeMove(i,j);
                        int b = search(*s,depth-1);
                        if(b > a)
                        {
                            a = b;
                        }
                    }
                }
            }
            return a;
        }
        
    }
    return result;
    
}

std::pair<int, int> johnc16::MyOthelloAI::chooseMove(const OthelloGameState& state)
{
    std::unique_ptr<OthelloGameState> s = state.clone();
    if(s->isBlackTurn() == true)
    {
        ai = true;
    }
    else
    {
        ai = false;
    }
    for(unsigned int i = 0;i<=s->board().width()-1;i++)
        {
            for(unsigned int j =0;j<=s->board().height()-1;j++)
            {
                if(s->isValidMove(i,j))
                {
                    best.first = i;
                    best.second = j;
                    int m = search(state,depth);
                    if(m>score)
                    {
                        score = i;
                        best.first = i;
                        best.second = j;
                    }
                }
            }
        }
    return best;
}

