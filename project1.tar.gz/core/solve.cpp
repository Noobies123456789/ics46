#include "solve.hpp"
#include <ics46/factory/DynamicFactory.hpp>
#include "Maze.hpp"
#include "MazeSolution.hpp"
#include <vector>
#include <random>
ICS46_DYNAMIC_FACTORY_REGISTER(MazeSolver,solve,"The Solve");

solve::solve()
    :endx{0},endy{0},currentx{0},currenty{0}
{
}

void solve::solveMaze(const Maze& maze,MazeSolution& mazeSolution)
{
    mazeSolution.restart();
    int b = 0;
    int a[4] = {0,0,0,0};
    std::pair end = mazeSolution.getEndingCell();
    endx = end.first;
    endy = end.second;
    std::vector<std::vector<int> > c(maze.getHeight(),std::vector<int>(maze.getWidth()));
    while(mazeSolution.isComplete() == false)
    {
        
        std::pair current = mazeSolution.getCurrentCell();
        currenty = current.second;
        currentx = current.first;
        c[currenty][currentx] = 1;
        std::vector<int> z;
        if(maze.wallExists(currentx,currenty,Direction::up) == false)
        {
            if(c[currenty-1][currentx] == 0)
            {
                a[0] = 1;
            }
            else
            {
                a[0] = 0;
            }
        }
        else
        {
            a[0] = 0;
        }
        if(maze.wallExists(currentx,currenty,Direction::right) == false)
        {
            if(c[currenty][currentx+1] == 0)
            {
                a[1] = 1;
            }
            else
            {
                a[1] = 0;
            }
        }
        else
        {
            a[1] = 0;
        }
        if(maze.wallExists(currentx,currenty,Direction::down) == false)
        {
            if(c[currenty+1][currentx] == 0)
            {
                a[2] = 1;
            }
            else
            {
                a[2] = 0;
            }
        }
        else
        {
            a[2] = 0;
        }
        if(maze.wallExists(currentx,currenty,Direction::left) == false)
        {
            if(c[currenty][currentx-1] == 0)
            {
                a[3] = 1;
            }
            else
            {
                a[3] = 0;
            }
        }
        else
        {
            a[3] = 0;
        }
        for(unsigned int i =0;i<4;i++)
        {
            if(a[i] == 1)
                z.push_back(i);
        }
        if(z.size() == 3 || z.size() == 0)
        {
            mazeSolution.backUp();
        }
        else
        {
            if(z.size()>1)
            {
                int lol = rand() % z.size();
                b = z[lol];
            }
            else
            {
                if(z.size() == 1)
                {
                    b = z[0];
                }
                else 
                {
                    b = 5;
                }
            }
            
            if(b == 0)
            {
                mazeSolution.extend(Direction::up);
            }
            if(b == 1)
            {
                mazeSolution.extend(Direction::right);
            }
            if(b == 2)
            {
                mazeSolution.extend(Direction::down);
            }
            if(b == 3)
            {
                mazeSolution.extend(Direction::left);
            }
        }
        
    }
}