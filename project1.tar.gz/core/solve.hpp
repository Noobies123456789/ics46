#ifndef SOLVE_HPP
#define SOLVE_HPP

#include "MazeSolver.hpp"

class solve : public MazeSolver
{
public:
    solve();
    void solveMaze(const Maze& maze,MazeSolution& mazeSolution) override;
private:
    unsigned int endx;
    unsigned int endy;
    unsigned int currentx;
    unsigned int currenty;
};

#endif