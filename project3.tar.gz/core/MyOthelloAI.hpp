#ifndef MYOTHELLOAI_HPP
#define MYOTHELLOAI_HPP

#include "OthelloAI.hpp"


namespace johnc16
{
    class MyOthelloAI : public OthelloAI
    {
    public:
        std::pair<int, int> chooseMove(const OthelloGameState& state) override;
        int search(const OthelloGameState& s, int depth);
        int eval(const OthelloGameState& state,OthelloCell& x);
    private:
        int depth = 2;
        std::pair<int,int> best = {0,0};
        int result = 0;
        int score = -999;
        bool ai;
    };
}

#endif