#include "test.hpp"
#include <ics46/factory/DynamicFactory.hpp>
#include "Maze.hpp"
#include <random>
#include <vector>
ICS46_DYNAMIC_FACTORY_REGISTER(MazeGenerator,test,"The Algorithm");


test::test()
    :x{0},y{0},direction{0},previousx{0},previousy{0}
{
}

void test::generateMaze(Maze& maze)
{
    maze.addAllWalls();
    int maxx = maze.getHeight();
    int maxy = maze.getWidth();
    std::random_device device;
    std::default_random_engine engine{device()};
    std::uniform_int_distribution<int> distribution{1, 4};
    std::vector<std::vector<int> > a(maxx,std::vector<int>(maxy));
    std::vector<int> m;
    std::vector<int> n;
    a[0][0] = 1;
    while(true)
    {
        direction = distribution(engine);
        if(direction == 1 && x != 0)
        {
            if(maze.wallExists(y,x,Direction::up) == true)
            {
                if(a[x-1][y] == 0)
                {
                    maze.removeWall(y,x,Direction::up);
                    previousx = x;
                    previousy = y;
                    m.push_back(x);
                    n.push_back(y);
                    x--;
                    a[x][y] = 1;
                }         
            }
        }
        if(direction == 2 && y != maxy-1)
        {
            if(maze.wallExists(y,x,Direction::right) == true)
            {
                if(a[x][y+1] == 0)
                {
                    maze.removeWall(y,x,Direction::right);
                    previousx = x;
                    previousy = y;
                    m.push_back(x);
                    n.push_back(y);
                    y++;
                    a[x][y] = 1;
                }
            }
        }
        if(direction == 3 && x != maxx-1)
        {
            if(maze.wallExists(y,x,Direction::down) == true)
            {
                if(a[x+1][y] == 0)
                {
                    maze.removeWall(y,x,Direction::down);
                    previousx = x;
                    previousy = y;
                    m.push_back(x);
                    n.push_back(y);
                    x++;
                    a[x][y] = 1;
                }
               
            }
        }
        if(direction == 4 && y != 0)
        {
            if(maze.wallExists(y,x,Direction::left) == true)
            {
                if(a[x][y-1] == 0)
                {
                    maze.removeWall(y,x,Direction::left);
                    previousx = x;
                    previousy = y;
                    m.push_back(x);
                    n.push_back(y);
                    y--;
                    a[x][y] = 1;
                }
            }
        }
        if(direction == 1 && x == 0)
        {
            if(y!=0)
            {
                if( a[x+1][y] == 1 && a[x][y-1] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else if(y==maxy-1)
            {
                if( a[x+1][y] == 1 && a[x][y-1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else
            {
                if( a[x+1][y] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
        }
        if(direction == 2 && y == maxy-1)
        {
            if(x == 0)
            {
                if( a[x+1][y] == 1 && a[x][y-1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else if(x==maxx-1)
            {
                if(a[x-1][y] == 1 && a[x][y-1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else
            {
                if( a[x+1][y] == 1 && a[x-1][y] == 1 && a[x][y-1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
        }
        if(direction == 3 && x == maxx-1)
        {
            if(y!=0)
            {
                if( a[x-1][y] == 1 && a[x][y-1] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else if(y==maxy-1)
            {
                if( a[x-1][y] == 1 && a[x][y-1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else
            {
                if( a[x-1][y] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
        }
        if(direction == 4 && y == 0)
        {
            if(x == 0)
            {
                if( a[x+1][y] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else if(x==maxx-1)
            {
                if(a[x-1][y] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                    
                }
            }
            else
            {
                if( a[x+1][y] == 1 && a[x-1][y] == 1 && a[x][y+1] == 1)
                {
                    x = m.back();
                    y = n.back();
                    m.pop_back();
                    n.pop_back();
                }
            }
        }
        if(x!=0 && y!=0 && x!=maxx-1 && y != maxy-1)
        {
            if(a[x+1][y] == 1 && a[x-1][y] == 1 && a[x][y+1] == 1 && a[x][y-1] == 1)
            {
                x = m.back();
                y = n.back();
                m.pop_back();
                n.pop_back();
                
            }
        }
        int sum=0;
        for(int i =0;i<a.size();i++)
        {
            for(int j=0;j<a[i].size();j++)
            {
                sum+=a[i][j];
            }
            
        }
        if(sum == maxx*maxy)
        {
            break;
        }
    }
}
