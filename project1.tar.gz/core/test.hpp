#ifndef TEST_HPP
#define TEST_HPP

#include "MazeGenerator.hpp"

class test : public MazeGenerator
{
public:
    test();
    void generateMaze(Maze& maze) override;
private:
    unsigned int x;
    unsigned int y;
    unsigned int direction;
    unsigned int previousx;
    unsigned int previousy;

};

#endif