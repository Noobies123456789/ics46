// main.cpp
//
// ICS 46 Winter 2022
// Project #5: Rock and Roll Stops the Traffic
//
// This is the program's main() function, which is the entry point for your
// console user interface.
#include "RoadMapReader.hpp"
#include "RoadMapWriter.hpp"
#include "TripReader.hpp"
#include <iostream>
#include <map>
double path(const RoadSegment& s)
{
    return s.miles;
}

double times(const RoadSegment& s)
{
    return s.miles/(double)s.milesPerHour;
}
int main()
{
    InputReader i  = InputReader(std::cin);
    RoadMapReader r;
    RoadMap m = r.readRoadMap(i);
    TripReader t;
    std::vector<Trip> v = t.readTrips(i);

    struct uwu
    {
        int vertex;
        std::string name;
        RoadSegment edge;
        
    };

    std::map<int,int> shorty;
    for(auto x = v.begin();x!=v.end();x++)
    {
        //double d = 0.0;
        if(x->metric == TripMetric::Distance)
        {
            std::cout << "Shortest distance from "<< m.vertexInfo(x->startVertex) << " to " << m.vertexInfo(x->endVertex) <<": " << std::endl;
            shorty = m.findShortestPaths(x->startVertex,times);
        }
        else
        {
            std::cout << "Shortest driving time from "<< m.vertexInfo(x->startVertex) << " to " << m.vertexInfo(x->endVertex) <<": " << std::endl;
            shorty = m.findShortestPaths(x->startVertex,path);
        }
        std::cout << "  Begin at " << m.vertexInfo(x->startVertex) << std::endl;
        
        
    }
    return 0;
}

