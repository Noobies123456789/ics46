// WordChecker.cpp
//
// ICS 46 Winter 2022
// Project #4: Set the Controls for the Heart of the Sun
//
// Replace and/or augment the implementations below as needed to meet
// the requirements.

#include "WordChecker.hpp"



WordChecker::WordChecker(const Set<std::string>& words)
    : words{words}
{
}


bool WordChecker::wordExists(const std::string& word) const
{
    if(words.contains(word))
    {
        return true;
    }
    return false;
}


std::vector<std::string> WordChecker::findSuggestions(const std::string& word) const
{
    std::vector<std::string> suggestion;
    std::string wrd = word;
    char alphabet[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    for(unsigned int i = 0;i < wrd.length();i++)
    {
        if(i<wrd.length()-1)
        {
            std::string w = wrd;
            char hold;
            hold = w[i+1];
            w[i+1] = w[i];
            w[i] = hold;
            if(wordExists(w))
            {
                suggestion.push_back(w);
            }
        }
        for(unsigned int j = 0;j<26;j++)
        {
            std::string a = wrd;
            a.insert(i,1,alphabet[j]);
            if(wordExists(a))
            {
                suggestion.push_back(a);
            }
        }
        std::string b = wrd;
        b.erase(i,1);
        if(wordExists(b))
        {
            suggestion.push_back(b);
        }
        for(unsigned int j = 0;j<26;j++)
        {
            std::string c = wrd;
            c[i] = alphabet[j];
            if(wordExists(c))
            {
                suggestion.push_back(c);
            }
        }

        std::string d = wrd.substr(0,i);
        std::string e = wrd.substr(i);
        if(wordExists(d) == true && wordExists(e) == true)
        {
            std::string f = d + " " + e;
            suggestion.push_back(f);
        }

    }

    return suggestion;
}

