// String.cpp
//
// ICS 46 Winter 2022
// Project #0: Getting to Know the ICS 46 VM
//
// Implement all of your String member functions in this file.
//
// Note that the entire standard library -- both the C Standard
// Library and the C++ Standard Library -- is off-limits for this
// task, as the goal is to exercise your low-level implementation
// skills (pointers, memory management, and so on).

#include "String.hpp"
#include "OutOfBoundsException.hpp"
#include <iostream>
String::String()
    :a{nullptr}
{

}

String::String(const char* chars)
    :a{nullptr}
{
    a = (char*)chars;
}

String::String(const String& s)
    :a{s.a}
{

}

String::~String() noexcept
{
    clear();
    delete[] a;
    b = nullptr;
    delete[] b;
}

String& String::operator=(const String& s)
{
    char* hold = nullptr;
    hold = s.a;
    a = hold;
    
    return *this;
}

void String::append(const String& s)
{
    unsigned int original = length();
    unsigned int origin = s.length();
    unsigned int add = original + origin;
    unsigned int j=0;
    char* x = new char[add];
    for(unsigned int i = 0;i<original;i++)
    {
        x[i] = a[i];
    }
    for(unsigned int i = original;i<add;i++)
    {
        x[i] = s.a[j];
        j++;
    }
    a = x;
}

char String::at(unsigned int i) const
{
    try
    {
        if(i < length())
        {
            return a[i];
        }
        throw OutOfBoundsException();
    }
    catch(OutOfBoundsException e)
    {
        
        throw e;
    }
    return a[i];
}

char& String::at(unsigned int i)
{
    try
    {
        if(i < length())
        {
            return a[i];
        }
        throw OutOfBoundsException();
    }
    catch(OutOfBoundsException e)
    {
        throw e;
    }
    return a[i];
}

void String::clear()
{
    a = nullptr;
}

int String::compareTo(const String& s) const noexcept
{
    if(length() == s.length())
    {
        return 0;
    };
    if(length() > s.length())
    {
        return -1;
    }
    return 1;
}

String String::concatenate(const String& s) const
{
    unsigned int original = length();
    unsigned int origin = s.length();
    unsigned int add = original + origin;
    unsigned int j=0;
    for(unsigned int i = 0;i<original;i++)
    {
        b[i] = a[i];
    }
    for(unsigned int i = original;i<add;i++)
    {
        b[i] = s.a[j];
        j++;
    }
    return b;
}

bool String::contains(const String& substring) const noexcept
{
    unsigned int k = 0;
    for(unsigned int i =0;i<length();i++)
    {
        if(a[i] == substring.a[0])
        {
            k = i;
            for(unsigned int j = 0;j<substring.length();j++)
            {
                if(a[k]!=substring.a[j])
                {
                    return false;
                }
                k++;
            }
        }
    }
    return true;
}

bool String::equals(const String& s) const noexcept
{
    if(a == s.a)
    {
        return true;
    }
    return false;
}

int String::find(const String& s) const noexcept
{
    unsigned int k = 0;
    int m = 0;
    for(unsigned int i =0;i<length();i++)
    {
        if(a[i] == s.a[0])
        {
            k = i;
            m = i;
            for(unsigned int j = 0;j<s.length();j++)
            {
                if(a[k]!=s.a[j])
                {
                    m = -1;
                    return m;
                }
                k++;
            }
        }
    }
    return m;
}

bool String::isEmpty() const noexcept
{
    if(a == nullptr || length() == 0)
    {
        return true;
    }
    return false;
}

unsigned int String::length() const noexcept
{
    unsigned int x = 0;
    if(a != nullptr)
    {
        while(a[x] != '\0')
        {
            x++;
        }
    }
    return x;
}

String String::substring(unsigned int start, unsigned int end) const
{
    String s;
    try
    {
        if(length() < start || length() < end)
        {
            throw OutOfBoundsException();
        }
        unsigned int j = 0;
        char* b = new char[end-start];
        for(unsigned int i = start;i<end;i++)
        {
            b[j] = a[i];
            j++;
        }
        s = b;
    }
    catch(OutOfBoundsException e)
    {
        throw OutOfBoundsException();
    }
    
    
    return s;
}

const char* String::toChars() const noexcept
{
    if(isEmpty())
    {
        return "";
    }
    return a;
}

