// AVLSet.hpp
//
// ICS 46 Winter 2022
// Project #4: Set the Controls for the Heart of the Sun
//
// An AVLSet is an implementation of a Set that is an AVL tree, which uses
// the algorithms we discussed in lecture to maintain balance every time a
// new element is added to the set.  The balancing is actually optional,
// with a bool parameter able to be passed to the constructor to explicitly
// turn the balancing on or off (on is default).  If the balancing is off,
// the AVL tree acts like a binary search tree (e.g., it will become
// degenerate if elements are added in ascending order).
//
// You are not permitted to use the containers in the C++ Standard Library
// (such as std::set, std::map, or std::vector) to store the information
// in your data structure.  Instead, you'll need to implement your AVL tree
// using your own dynamically-allocated nodes, with pointers connecting them,
// and with your own balancing algorithms used.

#ifndef AVLSET_HPP
#define AVLSET_HPP

#include <functional>
#include "Set.hpp"

template <typename ElementType>
class AVLSet : public Set<ElementType>
{
public:
    // A VisitFunction is a function that takes a reference to a const
    // ElementType and returns no value.
    using VisitFunction = std::function<void(const ElementType&)>;

public:
    // Initializes an AVLSet to be empty, with or without balancing.
    explicit AVLSet(bool shouldBalance = true);

    // Cleans up the AVLSet so that it leaks no memory.
    ~AVLSet() noexcept override;

    // Initializes a new AVLSet to be a copy of an existing one.
    AVLSet(const AVLSet& s);

    // Initializes a new AVLSet whose contents are moved from an
    // expiring one.
    AVLSet(AVLSet&& s) noexcept;

    // Assigns an existing AVLSet into another.
    AVLSet& operator=(const AVLSet& s);

    // Assigns an expiring AVLSet into another.
    AVLSet& operator=(AVLSet&& s) noexcept;


    // isImplemented() should be modified to return true if you've
    // decided to implement an AVLSet, false otherwise.
    bool isImplemented() const noexcept override;


    // add() adds an element to the set.  If the element is already in the set,
    // this function has no effect.  This function always runs in O(log n) time
    // when there are n elements in the AVL tree.
    void add(const ElementType& element) override;


    // contains() returns true if the given element is already in the set,
    // false otherwise.  This function always runs in O(log n) time when
    // there are n elements in the AVL tree.
    bool contains(const ElementType& element) const override;


    // size() returns the number of elements in the set.
    unsigned int size() const noexcept override;


    // height() returns the height of the AVL tree.  Note that, by definition,
    // the height of an empty tree is -1.
    int height() const noexcept;


    // preorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by a preorder traversal of the AVL
    // tree.
    void preorder(VisitFunction visit) const;


    // inorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by an inorder traversal of the AVL
    // tree.
    void inorder(VisitFunction visit) const;


    // postorder() calls the given "visit" function for each of the elements
    // in the set, in the order determined by a postorder traversal of the AVL
    // tree.
    void postorder(VisitFunction visit) const;


private:
    struct Node
    {
        ElementType value;
        Node* left;
        Node* right;
    };
    Node* root;
    unsigned int sz;
    void deletenode(Node* n);
    void copy(Node* a,Node*& b);
    void balance(const ElementType& e, Node*& a);
    int high(Node* a) const;
    bool contain(const ElementType& e, Node* a) const;
    void rightrotate(Node* a);
    void leftrotate(Node* a);
    bool balancer;
    void pre(Node* r,VisitFunction v) const;
    void in(Node* r,VisitFunction v) const;
    void post(Node* r,VisitFunction v) const;
};


template <typename ElementType>
AVLSet<ElementType>::AVLSet(bool shouldBalance)
    : root {nullptr},sz{0}, balancer{shouldBalance}
{
}

template <typename ElementType>
void AVLSet<ElementType>::deletenode(Node* tree){
    if(tree == nullptr)
    {
        return;
    }
    deletenode(tree->right);
    deletenode(tree->left);
    delete tree;
    
}

template <typename ElementType>
AVLSet<ElementType>::~AVLSet() noexcept
{
    deletenode(root);
}

template <typename ElementType>
void AVLSet<ElementType>::copy(Node* old,Node*& nw)
{
    if(old == nullptr)
    {
        nw = nullptr;
    }
    else
    {
         while (old)
        {  
            nw->value = old->value;
            if (old->right != nullptr)
            {
                copy(old->right,nw->right);
            }
            if (old->left != nullptr)
            {
                copy(old->left,nw->left);
            }
        }
    }
}

template <typename ElementType>
AVLSet<ElementType>::AVLSet(const AVLSet& s)
{
    copy(s.root,root);
    sz = s.sz;
}


template <typename ElementType>
AVLSet<ElementType>::AVLSet(AVLSet&& s) noexcept
{
    copy(s.root,root);
    sz = s.sz;
    deletenode(s.root);
}


template <typename ElementType>
AVLSet<ElementType>& AVLSet<ElementType>::operator=(const AVLSet& s)
{
    if(this!=&s)
    {
        delete(root);
        copy(s.root,root);
        sz = s.sz;
    }
    return *this;
}


template <typename ElementType>
AVLSet<ElementType>& AVLSet<ElementType>::operator=(AVLSet&& s) noexcept
{
    if(this!=&s)
    {
        delete(root);
        copy(s.root,root);
        sz = s.sz;
        deletenode(s.root);
    }
    return *this;
}


template <typename ElementType>
bool AVLSet<ElementType>::isImplemented() const noexcept
{
    return true;
}

template <typename ElementType>
void AVLSet<ElementType>::leftrotate(Node* a)
{
    Node *x = a->left;
    Node *y = x->right;
    x->right = a;
    a->left = y;
    
}

template <typename ElementType>
void AVLSet<ElementType>::rightrotate(Node* a)
{
    Node *x = a->right;
    Node *y = x->left;
    x->left = a;
    a->right = y;
    
}

template <typename ElementType>
void AVLSet<ElementType>::balance(const ElementType& element,Node*& a)
{
    if (a == nullptr)
    {
        a = new Node{element};
    }
    if (element < a->value)
    {
        balance(element,a->left);
    }
    else if (element > a->value)
    {
        balance(element,a->right);
    }
    
    
}

template <typename ElementType>
void AVLSet<ElementType>::add(const ElementType& element)
{
    if(contains(element))
    {
        return;
    }
    else
    {

        balance(element,root);
        
        sz++;
    }
}

template <typename ElementType>
bool AVLSet<ElementType>::contain(const ElementType& element, Node* r) const
{
    if(r == nullptr)
    {
        return false;
    }
    else if(r -> value == element)
    {
        return true;
    }
    else if(r->value > element)
    {
        return contain(element,r->left);
    }
    else if(r->value <element)
    {
        return contain(element, r->right);
    }
    return false;
}

template <typename ElementType>
bool AVLSet<ElementType>::contains(const ElementType& element) const
{
    return contain(element,root);
}


template <typename ElementType>
unsigned int AVLSet<ElementType>::size() const noexcept
{
    return sz;
}

template <typename ElementType>
int AVLSet<ElementType>::high(Node* r) const
{
    if(r == nullptr)
    {
        return -1;
    }
    else
    {
        int left= 1+high(r->left);
        int right= 1+high(r->right);
        
        if(left < right)
        {
            
            return right++;
        }
        else
        {
            return left++;
        }
    }
}

template <typename ElementType>
int AVLSet<ElementType>::height() const noexcept
{
    return high(root);
}

template <typename ElementType>
void AVLSet<ElementType>::pre(Node*r, VisitFunction v) const
{
    if(r!=nullptr)
    {
        v(r->value);
        pre(r->left,v);
        pre(r->right,v);
    }
}

template <typename ElementType>
void AVLSet<ElementType>::preorder(VisitFunction visit) const
{
    pre(root, visit);
}

template <typename ElementType>
void AVLSet<ElementType>::in(Node*r, VisitFunction v) const
{
    if(r!=nullptr)
    {
        in(r->left,v);
        v(r->value);
        in(r->right,v);
    }
}

template <typename ElementType>
void AVLSet<ElementType>::inorder(VisitFunction visit) const
{
    in(root,visit);
}

template <typename ElementType>
void AVLSet<ElementType>::post(Node*r, VisitFunction v) const
{
    if(r!=nullptr)
    {
        post(r->left,v); 
        post(r->right,v);
        v(r->value);
    }
    
}
template <typename ElementType>
void AVLSet<ElementType>::postorder(VisitFunction visit) const
{
    post(root,visit);
}



#endif

